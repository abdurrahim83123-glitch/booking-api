
CREATE DATABASE service_booking;
USE service_booking;
CREATE TABLE services(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(50),price INT,status INT);
CREATE TABLE bookings(id INT AUTO_INCREMENT PRIMARY KEY,service_id INT,name VARCHAR(50),mobile VARCHAR(15),date DATE,time TIME,status VARCHAR(20));
INSERT INTO services(name,price,status) VALUES('Electrical Works',299,1),('Plumbing Works',249,1);
