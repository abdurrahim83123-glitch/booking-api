<?php
header('Content-Type: application/json');
include '../config/db.php';

// Fetch all active services
$result = $conn->query("SELECT * FROM services WHERE status=1");

$services = [];
while($row = $result->fetch_assoc()){
    $services[] = $row;
}

// Return JSON
echo json_encode($services);
?>
